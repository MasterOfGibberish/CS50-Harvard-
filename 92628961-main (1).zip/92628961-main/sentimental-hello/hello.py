name = input("What is your name? ")  # askes to write a name
print("hello, " + name)  # prints the name
